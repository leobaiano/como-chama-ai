<?php

	class LuxeSlide {
		
		private $id;
		private $parent;
		private $slideOrder;
		
		private $imageUrl;
		private $imageFilepath;
		private $imageFilename;
		
		private $params;
		private $arrLayers;
		
		public function __construct(){
			$plugin = LuxeSliderPlugin::get_instance();
			$this->plugin_slug = $plugin->get_plugin_slug();	
		}
		

    /**
     * Set the current slider
     */
    public function set_slide($slide_id) {
    	$this->id = $slide_id;
    	$this->parent = $this->get_parent();
    }

	/**
	 * get the parent slider id
	 */
	public function get_parent(){
        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT slider_id FROM $table WHERE id = $this->id" );
		return $result->slider_id;
	}

	/**
	 * find slider by order and parent
	 */
    public function find_slide($orderby = 'id', $order = 'DESC', $parent_id = null) {

        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT id FROM $table WHERE slider_id = $parent_id ORDER BY $orderby $order" );

        if ($result) {
            return $result->id;
        }

        return false;
    }


    /**
     * Create a new slider
     */
    public function add_slide($data) {

        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;	

		//create slide	
		$result = $wpdb->insert($table, $data);
		$slide_id = $wpdb->insert_id;
		return($slide_id);

    }


    /**
     * Update slider (save) @TODO add prepare to this and all sql entries
     */
	public function update_slide($slide_id = null, $data){

		check_admin_referer($this->plugin_slug . '_save');

		// @TODO get post options and clean
        $data = array();
		$data["title"] = sanitize_text_field( $_POST['slide_title'] );
		$data["settings"] = serialize($_POST['slide_settings']); 

		

		// format array of sliders for future use
		$layers = array();
		$fields = array('content', 'position_x', 'position_y', 'step', 'duration', 'delay', 'animation_in', 'easing_in', 'animation_out', 'easing_out');
		for ($i=0; $i < count($_POST['slide_layers']['content']);$i++)
		{
			if($_POST['slide_layers']['content'][$i]) {
				foreach ($fields as $field) {
					$layers[$i][$field] = isset($_POST['slide_layers'][$field][$i]) ? stripslashes($_POST['slide_layers'][$field][$i]) : '';
				}
			}
		}
		// avoid escaping of any illegal characters
		$data["layers"] = serialize($layers); 
        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;	

		if(!empty($slide_id)){	
			//create slider	
			$result = $wpdb->update($table, $data, array('id'=>$slide_id));
			$slider_id = $wpdb->insert_id;
			return($slider_id);
		}

	}

    /**
     * Delete a slide and layers 
     *
     * @param int $id
     */
    public function delete_slide() {
        // check nonce
        check_admin_referer($this->plugin_slug."_delete_slide");

        global $wpdb;
        $slides_table_suffix = '_slides';
		$slides_table = $wpdb->prefix.$this->plugin_slug.$slides_table_suffix;	

		//delete all slides associated 
		$wpdb->query( 
			$wpdb->prepare( 
				"
		         DELETE FROM $slides_table
				 WHERE id = %d
				",
			        $this->id 
		        )
		);
    }

	/**
	 * Get slide settings
	 */
	public function get_settings(){
        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT * FROM $table WHERE id = $this->id" );
		$settings = unserialize($result->settings);
		return $settings;
	}

	/**
	 * Get slide layers
	 */
	public function get_layers(){
        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT * FROM $table WHERE id = $this->id" );
		$layers = unserialize($result->layers);

		return $layers;
	}

		/**
		 * 
		 * init slide by db record
		 */
		public function initByData($record){
			
			$this->id = $record["id"];
			$this->sliderID = $record["slider_id"];
			$this->slideOrder = $record["slide_order"];
			
			$params = $record["params"];
			$params = (array)json_decode($params);
			
			$layers = $record["layers"];
			$layers = (array)json_decode($layers);
			$layers = UniteFunctionsRev::convertStdClassToArray($layers);
			
			//set image path, file and url
			$this->imageUrl = UniteFunctionsRev::getVal($params, "image");
			UniteFunctionsRev::validateNotEmpty($this->imageUrl,"Image");
			
			$this->imageFilepath = UniteFunctionsWPRev::getImagePathFromURL($this->imageUrl);
		    $realPath = UniteFunctionsWPRev::getPathContent().$this->imageFilepath;
		    
		    if(file_exists($realPath) == false || is_file($realPath) == false)
		    	$this->imageFilepath = "";
		    
			$this->imageFilename = basename($this->imageUrl);
			
			$this->params = $params;
			$this->arrLayers = $layers;	
		}
		
		
		/**
		 * 
		 * init the slider by id
		 */
		public function initByID($slideid){
			UniteFunctionsRev::validateNumeric($slideid,"Slide ID");
			$slideid = $this->db->escape($slideid);
			$record = $this->db->fetchSingle(GlobalsRevSlider::$table_slides,"id=$slideid");
			
			$this->initByData($record);
		}
		
		/**
		 * 
		 * get slide ID
		 */
		public function getID(){
			return($this->id);
		}
		
		
		/**
		 * 
		 * get slide order
		 */
		public function getOrder(){
			$this->validateInited();
			return($this->slideOrder);
		}
		
		

		

		
		
		/**
		 * 
		 * sort layers by order
		 */
		private function sortLayersByOrder($layer1,$layer2){
			$order1 = UniteFunctionsRev::getVal($layer1, "order",1);
			$order2 = UniteFunctionsRev::getVal($layer2, "order",2);
			if($order1 == $order2)
				return(0);
			
			return($order1 > $order2);
		}
		

		
		
	}
	
?>