<?php


    $title = "";
    $add_url = wp_nonce_url("?page=".$plugin_slug."&amp;add_slider=true", $plugin_slug."_add_slider");



    if ($sliders = $slider->all_sliders()) {
        if ($max_tabs && count($sliders) > $max_tabs) {
            if (isset($_GET['add']) && $_GET['add'] == 'true') {
                echo "<div id='message' class='updated'><p>" . __("New slideshow created. Click 'Add Slide' to get started!", $plugin_slug) . "</p></div>";
            }
            echo "<div style='margin-top: 20px;'><label for='select-slider'>Select Slider: </label>";
            echo "<select name='select-slider' onchange='if (this.value) window.location.href=this.value'>";

            $sliders = $this->all_sliders('title');

            foreach ($sliders as $tab) {
                $selected = $tab['active'] ? " selected" : "";

                if ($tab['active']) {
                    $title = $tab['title'];
                }

                echo "<option value='?page=".$plugin_slug."&amp;slider_id={$tab['id']}'{$selected}>{$tab['title']}</option>";

            }
            echo "</select> " . __('or', $plugin_slug) . " ";
            echo "<a href='{$add_url}'>" . __('Add New Slideshow', $plugin_slug) . "</a></div>";
        } else {
            echo "<h3 class='nav-tab-wrapper'>";
            foreach ($sliders as $tab) {
                if ($tab['active']) {
                    echo "<div class='nav-tab nav-tab-active'><input type='text' name='title'  value='" . $tab['title'] . "' onfocus='this.style.width = ((this.value.length + 1) * 9) + \"px\"' /></div>";
                } else {
                    echo "<a href='?page=".$plugin_slug."&amp;slider_id={$tab['id']}' class='nav-tab'>" . $tab['title'] . "</a>";
                }
            }
            echo "<a href='{$add_url}' id='create_new_tab' class='nav-tab'>+</a>";
            echo "</h3>";
        }
    } else {
        echo "<h3 class='nav-tab-wrapper'>";
        echo "<a href='{$add_url}' id='create_new_tab' class='nav-tab'>+</a>";
        echo "<div class='bubble'>" . __("Create your first slider") . "</div>";
        echo "</h3>";
    }

    $add_slide_url = wp_nonce_url("?page=".$plugin_slug."&amp;slider_id={$this->slider}&amp;add_slide=true", $plugin_slug."_add_slide");

    if($this->slider) {

    if ($slides = $slider->all_slides()) {
            echo "<h4 class='nav-tab-wrapper sortable'>";
            foreach ($slides as $tab) {
                if ($tab['active']) {
                    echo "<div class='nav-tab nav-tab-active'><input type='text' name='slide_title'  value='" . $tab['title'] . "' onfocus='this.style.width = ((this.value.length + 1) * 9) + \"px\"' /></div>";
                } else {
                    echo "<a href='?page=".$plugin_slug."&amp;slider_id={$this->slider}&amp;slide_id={$tab['id']}' class='nav-tab sort'>" . $tab['title'] . "</a>";
                }
            }
            echo "<a href='{$add_slide_url}' id='create_new_tab' class='nav-tab'>+</a>";
            echo "</h4>";        
        }
        else {
                echo "<h4 class='nav-tab-wrapper'>";
                echo "<a href='{$add_slide_url}' id='create_new_tab' class='nav-tab'>+</a>";
                echo "<div class='bubble'>" . __("<-Create your first slide!") . "</div>";
                echo "</h4>";
        }
    }
?>