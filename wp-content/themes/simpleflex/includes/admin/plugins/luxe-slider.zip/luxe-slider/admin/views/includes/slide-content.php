<?php
if ( !$this->slide || !$this->slider ) {
    return;
}
?>
<?php 

$slide = new LuxeSlide();
$slide->set_slide($this->slide);
$slide_settings = $slide->get_settings(); 

$animations = array (
    'none' => 'None',
    'fade' => 'Fade',
    'left' => 'Left',
    'topLeft' => 'Top Left',
    'bottomLeft' => 'Bottom Left',
    'right' => 'Right',
    'topRight' => 'Top Right',
    'bottomRight' => 'Bottom Right',
    'top' => 'Top',
    'bottom' => 'Bottom'
    );

$easing =    array(
    'linear'           => 'linear',
    'swing'            => 'swing',
    'jswing'           => 'jswing',
    'easeInQuad'       => 'easeInQuad',
    'easeOutQuad'      => 'easeOutQuad',
    'easeInOutQuad'    => 'easeInOutQuad',
    'easeInCubic'      => 'easeInCubic',
    'easeOutCubic'     => 'easeOutCubic',
    'easeInOutCubic'   => 'easeInOutCubic',
    'easeInQuart'      => 'easeInQuart',
    'easeOutQuart'     => 'easeOutQuart',
    'easeInOutQuart'   => 'easeInOutQuart',
    'easeInQuint'      => 'easeInQuint',
    'easeOutQuint'     => 'easeOutQuint',
    'easeInOutQuint'   => 'easeInOutQuint',
    'easeInSine'       => 'easeInSine',
    'easeOutSine'      => 'easeOutSine',
    'easeInOutSine'    => 'easeInOutSine',
    'easeInExpo'       => 'easeInExpo',
    'easeOutExpo'      => 'easeOutExpo',
    'easeInOutExpo'    => 'easeInOutExpo',
    'easeInCirc'       => 'easeInCirc',
    'easeOutCirc'      => 'easeOutCirc',
    'easeInOutCirc'    => 'easeInOutCirc',
    'easeInElastic'    => 'easeInElastic',
    'easeOutElastic'   => 'easeOutElastic',
    'easeInOutElastic' => 'easeInOutElastic',
    'easeInBack'       => 'easeInBack',
    'easeOutBack'      => 'easeOutBack',
    'easeInOutBack'    => 'easeInOutBack',
    'easeInBounce'     => 'easeInBounce',
    'easeOutBounce'    => 'easeOutBounce',
    'easeInOutBounce'  => 'easeInOutBounce'
);  

?>

<div id='post-body-content'>
    <div class="left">

        <?php
            if (isset($_GET['add_slide']) && $_GET['add_slide'] == 'true') {
                echo "<div id='message' class='updated'><p>" . __("New slide created!", "luxe-slider") . "</p></div>";
            }
            else {

            }

        ?>

        <div id="slide_canvas" style="width:<?php echo $settings['slider_dimensions_x']; ?>px;height:<?php echo $settings['slider_dimensions_y']; ?>px;background-image:url('<?php echo $slide_settings['background_image']; ?>');background-repeat:no-repeat;background-position:center center;background-color:<?php echo $slide_settings['background_color']; ?>;"></div>


        <table class="widefat">
            <tbody>
                <tr class="slide-settings">
                    <th style="width: 130px;">
                        <h3><?php _e("Slide Settings", $plugin_slug) ?></h3>
                    </th>
                    <th style="">
                        <a href="#" class="slide_media_upload button" id="slide_media_upload"><?php _e("Upload Background Image", $plugin_slug) ?></a>
                        <input class="slide_media_url" id="slide_media_url" type="hidden" name="slide_settings[background_image]" value="<?php echo $slide_settings['background_image']; ?>">
                        <input class="slide_media_id" id="slide_media_id" type="hidden" name="slide_settings[attachment_id]" value="<?php echo $slide_settings['attachment_id']; ?>">
                        <a href="#" class="button" id="remove_background_image"><?php _e("Remove Background Image", $plugin_slug) ?></a>
                        <input type="text" value="<?php echo $slide_settings['background_color']; ?>" class="slide_background_color" id="slide_background_color" name="slide_settings[background_color]" data-default-color="" />

                    </th>

                    <th >
                        <a id="delete-slide" class='delete-slide alignright button-secondary confirm' href='<?php echo wp_nonce_url("?page=".$plugin_slug."&amp;delete_slide={$this->slide}", $plugin_slug."_delete_slide"); ?>'><?php _e("Delete Slide", $plugin_slug) ?></a>
                    </th>
                </tr>
            </tbody>


<?php


?>
        <table class="widefat sortable" id="repeatable-fieldset-one">
            <thead>
                <tr>
                    <th style="width: 40px;">
                        <h3><?php _e("Layers", $plugin_slug) ?></h3>
                    </th>
                    <th colspan="9">
                        <a href='#' id="add-layer" class='button alignright add-layer' data-editor='content' title='<?php _e("Add Layer", $plugin_slug) ?>'>
                            <span class='wp-media-buttons-icon'></span> <?php _e("Add Layer", $plugin_slug) ?>
                        </a>
                    </th>
                </tr>
            </thead>

            <tbody>
                <?php
                $slide_layers = $slide->get_layers(); 
                if ( $slide_layers ) :

                    foreach ( $slide_layers as $layer ) {
                    ?>
                        <tr class="slide-layer">
                            <td class="remove-layer">
                                <a class="button remove-row delete-layer" href="#">X</a>
                                <a class="sort button">|||</a> 
                            </td>
                            <td><label><?php _e('Content', $plugin_slug); ?><div class="customEditor"><textarea class="layer-content" name="slide_layers[content][]"><?php echo $layer['content']; ?></textarea></div></label></td>
                            <td>
                                <div class="layer-option"><label><?php _e('Position X', $plugin_slug); ?><input class="layer-position-x small-int" type="text" class="" name="slide_layers[position_x][]" value="<?php echo $layer['position_x']; ?>" /></label></div>
                                <div class="layer-option"><label><?php _e('Position Y', $plugin_slug); ?><input class="layer-position-y small-int" type="text" class="" name="slide_layers[position_y][]" value="<?php echo $layer['position_y']; ?>" /></label></div>
                                <div class="layer-option"><label><?php _e('Step', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[step][]" value="<?php echo $layer['step']; ?>" /></label></div>
                                <div class="layer-option"><label><?php _e('Duration', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[duration][]" value="<?php echo $layer['duration']; ?>" /></label></div>
                                <div class="layer-option"><label><?php _e('Delay', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[delay][]" value="<?php echo $layer['delay']; ?>" /></label></div>
                                <div class="layer-option">
                                    <label><?php _e('Animation In', $plugin_slug); ?>
                                    <select name="slide_layers[animation_in][]">
                                    <option value="">-----------------</option>
                                    <?php
                                    foreach($animations as $key => $value):
                                        $selected = ($layer['animation_in'] == $key) ? 'selected' : '';
                                        echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>'; //close your tags!!
                                    endforeach;
                                    ?>
                                    </select>
                                    </label>
                                </div>
                                <div class="layer-option">
                                    <label><?php _e('Easing In', $plugin_slug); ?>
                                    <select name="slide_layers[easing_in][]">
                                    <option value="">-----------------</option>
                                    <?php
                                    foreach($easing as $key => $value):
                                        $selected = ($layer['easing_in'] == $key) ? 'selected' : '';
                                        echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>'; //close your tags!!
                                    endforeach;
                                    ?>
                                    </select>
                                    </label>
                                </div>
                                <div class="layer-option">
                                    <label><?php _e('Animation Out', $plugin_slug); ?>
                                    <select name="slide_layers[animation_out][]">
                                    <option value="">-----------------</option>
                                    <?php
                                    foreach($animations as $key => $value):
                                        $selected = ($layer['animation_out'] == $key) ? 'selected' : '';
                                        echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>'; //close your tags!!
                                    endforeach;
                                    ?>
                                    </select>
                                    </label>
                                </div>
                                <div class="layer-option">
                                    <label><?php _e('Easing Out', $plugin_slug); ?>
                                    <select name="slide_layers[easing_out][]">
                                    <option value="">-----------------</option>
                                    <?php
                                    foreach($easing as $key => $value):
                                        $selected = ($layer['easing_out'] == $key) ? 'selected' : '';
                                        echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>'; //close your tags!!
                                    endforeach;
                                    ?>
                                    </select>
                                    </label>
                                </div>
                            </td>
                        </tr>
                    <?php
                    }
                else :
                    // show a blank one
            ?>
                <tr class="slide-layer">
                    <td class="remove-layer">
                        <a class="button remove-row delete-layer" href="#">X</a>
                        <a class="sort button">|||</a> 
                    </td>
                    <td><label><?php _e('Content', $plugin_slug); ?><div class="customEditor"><textarea class="layer-content" name="slide_layers[content][]"></textarea></div></label></td>
                    <td>
                        <div class="layer-option"><label><?php _e('Position X', $plugin_slug); ?><input class="layer-position-x small-int" type="text" class="" name="slide_layers[position_x][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Position Y', $plugin_slug); ?><input class="layer-position-y small-int" type="text" class="" name="slide_layers[position_y][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Step', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[step][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Duration', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[duration][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Delay', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[delay][]" value="0" /></label></div>
                        <div class="layer-option">
                            <label><?php _e('Animation In', $plugin_slug); ?>
                            <select name="slide_layers[animation_in][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($animations as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Easing In', $plugin_slug); ?>
                            <select name="slide_layers[easing_in][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($easing as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Animation Out', $plugin_slug); ?>
                            <select name="slide_layers[animation_out][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($animations as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Easing Out', $plugin_slug); ?>
                            <select name="slide_layers[easing_out][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($easing as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>

                <!-- empty hidden one for jQuery -->
                <tr class="empty-row screen-reader-text slide-layer">
                    <td class="remove-layer">
                        <a class="button remove-row delete-layer" href="#">X</a>
                        <a class="sort button">|||</a> 
                    </td>
                    <td><label><?php _e('Content', $plugin_slug); ?><div class="customEditor"><textarea class="layer-content" name="slide_layers[content][]"></textarea></div></label></td>
                    <td>
                        <div class="layer-option"><label><?php _e('Position X', $plugin_slug); ?><input class="layer-position-x small-int" type="text" class="" name="slide_layers[position_x][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Position Y', $plugin_slug); ?><input class="layer-position-y small-int" type="text" class="" name="slide_layers[position_y][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Step', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[step][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Duration', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[duration][]" value="0" /></label></div>
                        <div class="layer-option"><label><?php _e('Delay', $plugin_slug); ?><input type="text" class="small-int" name="slide_layers[delay][]" value="0" /></label></div>
                        <div class="layer-option">
                            <label><?php _e('Animation In', $plugin_slug); ?>
                            <select name="slide_layers[animation_in][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($animations as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Easing In', $plugin_slug); ?>
                            <select name="slide_layers[easing_in][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($easing as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Animation Out', $plugin_slug); ?>
                            <select name="slide_layers[animation_out][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($animations as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                        <div class="layer-option">
                            <label><?php _e('Easing Out', $plugin_slug); ?>
                            <select name="slide_layers[easing_out][]">
                            <option value="">-----------------</option>
                            <?php
                            foreach($easing as $key => $value):
                                echo '<option value="'.$key.'">'.$value.'</option>'; //close your tags!!
                            endforeach;
                            ?>
                            </select>
                            </label>
                        </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>
</div>
