(function ( $ ) {
	"use strict";

	$(function () {

		$("#delete-slider").click(function(e) {
		    if (!confirm("Do you really want to delete this slider and all of its slides?"))
		    {
		        e.preventDefault();
		        return false;
		    } 
		});
		$("#delete-slide").click(function(e) {
		    if (!confirm("Do you really want to delete this slide?"))
		    {
		        e.preventDefault();
		        return false;
		    } 
		});

	    /**
	     * Sortable slides
	     */
	    $('.nav-tab-wrapper.sortable').sortable({
	        opacity: 0.6,
	        revert: true,
	        cursor: 'move',
	        //handle: '.sort'
	    });



	    /**
	     * Slide canvas interaction
	     */
		var $slideCanvas = $('#slide_canvas');
		var count = 1;
		var layers = $(".slide-layer").not('.empty-row');
		layers.each(function(){
			$(this).attr('id', 'slide-layer-'+count);
			$(this).attr('data-layer', count);
			var layerContent = $(this).find('.layer-content').text();
		    var layerPositionX = $(this).find('.layer-position-x').val();
		    var layerPositionY = $(this).find('.layer-position-y').val();
	         $slideCanvas.append( '<div id="draggable-layer-'+count+'" class="draggable-layer" data-draggable-layer="'+count+'" style="left:'+layerPositionX+'px;top:'+layerPositionY+'px;">' + layerContent + '</div>' );
	         count++;
		});
		// update draggable layer with content from form
		layers.on('change', function() {
		    var draggableLayer = $("#draggable-layer-" + $(this).data('layer'));
		    var layerContent = $(this).find('.layer-content').val();
		    var layerPositionX = $(this).find('.layer-position-x').val();
		    var layerPositionY = $(this).find('.layer-position-y').val();
		    draggableLayer.html( layerContent );
		    draggableLayer.css({top: layerPositionY, left: layerPositionX});
		});
		// make element draggable
		$slideCanvas.find('.draggable-layer').draggable(
		    {
		        drag: function(){
		            var position = $(this).position();
		            var layer = $(this).data('draggable-layer');
		            $('#slide-layer-'+layer).find('.layer-position-x').val(parseInt(position.left));
		            $('#slide-layer-'+layer).find('.layer-position-y').val(parseInt(position.top));
		        }
		    });


	    /**
	     * Add new layers
	     */
	    $('#add-layer').on('click', function() {
	        var row = $('.empty-row.screen-reader-text').clone(true);
	        row.removeClass('empty-row screen-reader-text');
	        // add id to row and get contents for layer on canvas
			row.attr('id', 'slide-layer-'+count);
			row.attr('data-layer', count);
			var layerContent = row.find('.layer-content').text();
		    var layerPositionX = row.find('.layer-position-x').val();
		    var layerPositionY = row.find('.layer-position-y').val();
	        $slideCanvas.append( '<div id="draggable-layer-'+count+'" class="draggable-layer" data-draggable-layer="'+count+'" style="left:'+layerPositionX+'px;top:'+layerPositionY+'px;">' + layerContent + '</div>' );
	         // make new elment draggable
			$slideCanvas.find('.draggable-layer').draggable(
			    {
			        drag: function(){
			            var position = $(this).position();
			            var layer = $(this).data('draggable-layer');
			            $('#slide-layer-'+layer).find('.layer-position-x').val(parseInt(position.left));
			            $('#slide-layer-'+layer).find('.layer-position-y').val(parseInt(position.top));
			        }
			    });
			// update draggable layer with content from form
			row.on('change', function() {
			    var draggableLayer = $("#draggable-layer-" + $(this).data('layer'));
			    var layerContent = $(this).find('.layer-content').val();
			    var layerPositionX = $(this).find('.layer-position-x').val();
			    var layerPositionY = $(this).find('.layer-position-y').val();
			    draggableLayer.html( layerContent );
			    draggableLayer.css({top: layerPositionY, left: layerPositionX});
			});
	         count++;
	        row.insertBefore('#repeatable-fieldset-one tbody>tr:last');
	        return false;
	    });
	    $('.remove-row').on('click', function() {
	        $(this).parents('tr').remove();
	        return false;
	    });
	    /**
	     * Sortable/repeatable layer fields
	     */	 
	    $('#repeatable-fieldset-one tbody').sortable({
	        opacity: 0.6,
	        revert: true,
	        cursor: 'move',
	        handle: '.sort'
	    });


	    /**
	     * Slide setting options
	     */
		$('#slide_media_upload').click(function() {
			window.wpActiveEditor = null;
		    var send_attachment_bkp = wp.media.editor.send.attachment;

		    wp.media.editor.send.attachment = function(props, attachment) {

		        $('#slide_media_image').attr('src', attachment.url);
		        $('#slide_media_url').val(attachment.url);
		        $('#slide_media_id').val(attachment.id);
		        $slideCanvas.css('background-image', 'url('+attachment.url+')');

		        wp.media.editor.send.attachment = send_attachment_bkp;
		    }

		    wp.media.editor.open();

		    return false;       
		});
		$('#remove_background_image').click(function() {
	        $('#slide_media_image').attr('src', '');
	        $('#slide_media_url').val('');
	        $('#slide_media_id').val('');
	        $slideCanvas.css('background-image', '');
		    return false;       
		});
		$('#slide_background_color').wpColorPicker({
			change: function (event, ui) {
				$slideCanvas.css( "background-color", $(this).val() );
			},
			clear: function () {
				$slideCanvas.css( "background-color", $(this).val() );
			}
		});

		$('#move-sidebar').click(function() {
	        $('#post-body').toggleClass('columns-2')
		});



	});

}(jQuery));