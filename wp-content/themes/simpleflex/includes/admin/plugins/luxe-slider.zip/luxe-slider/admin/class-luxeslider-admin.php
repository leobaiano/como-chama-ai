<?php
/**
 * Plugin Name.
 *
 * @package   LuxeSliderAdmin
 * @author    Joshua Flowers <joshua@themeluxe.com>
 * @license   GPL-2.0+
 * @link      http://themeluxe.com
 * @copyright 2014 ThemeLuxe
 */

/**
 * This class handles the admin/dashbaord side of the slider
 * including creating, updating, and deleting new sliders/slides.
 */

class LuxeSliderAdmin {

	/** Current Slider **/
	var $slider = null;
	var $slide = null;
	var $slides = array();

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_screen_hook_suffix = null;

	/**
	 * Initialize the plugin by loading admin scripts & styles and adding a
	 * settings page and menu.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		$plugin = LuxeSliderPlugin::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();

		// Load admin style sheet and JavaScript.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		// Add the options page and menu item.
		add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );

		// Add an action link pointing to the options page.
		$plugin_basename = plugin_basename( plugin_dir_path( __DIR__ ) . $this->plugin_slug . '.php' );
		//add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'add_action_links' ) );

	}

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Register and enqueue admin-specific style sheet.
	 *
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_styles() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/admin.css', __FILE__ ), array(), LuxeSliderPlugin::VERSION );
		}

	}

	/**
	 * Register and enqueue admin-specific JavaScript.
	 *
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_scripts() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_media();
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_script( $this->plugin_slug . '-admin-script', plugins_url( 'assets/js/admin.js', __FILE__ ), array( "jquery", "jquery-ui-core", "jquery-ui-sortable", "editor" ) , LuxeSliderPlugin::VERSION );
		}

	}

	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 */
		$this->plugin_screen_hook_suffix = add_menu_page(
			__( 'Luxe Sliders', $this->plugin_slug ),
			__( 'Luxe Slider', $this->plugin_slug ),
			'manage_options',
			$this->plugin_slug,
			array( $this, 'display_plugin_admin_page' )
		);

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_admin_page() {
		include_once 'views/admin.php';
	}

	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	public function add_action_links( $links ) {

		return array_merge(
			array(
				'settings' => '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_slug ) . '">' . __( 'Settings', $this->plugin_slug ) . '</a>'
			),
			$links
		);

	}


	/**
	 * Handle slider uploads/changes.
	 */
	public function admin_process() {
		// this function should only ever be called from the Luxe Slider admin page.
		if ( !is_admin() ) {
			return;
		}

		$slider = new LuxeSlider();
		$slide = new LuxeSlide();
		$slider_id = 0;
		$slide_id = 0;

		// delete a slider
		if ( isset( $_GET['delete_slider'] ) ) {
			$slider->delete_slider( intval( $_GET['delete_slider'] ) );
		}

		// default to the latest slider
		$slider_id = $slider->find_slider( 'id', 'DESC' ); 

		// delete a slide
		if ( isset( $_GET['delete_slide'] ) ) {
			$slide->set_slide( intval( $_GET['delete_slide'] ) );
			$slider_id = $slide->get_parent();
			$slide->delete_slide();
		}

		// default to the latest slider
		$slide_id = $slide->find_slide( 'id', 'DESC', $slider_id ); 

		// create a new slider
		if ( isset( $_GET['add_slider'] ) ) {
			$slider_id = $slider->add_slider();
		}

		// create a new slider
		if ( isset( $_GET['add_slide'] ) ) {
			$slide_id = $slider->add_slide();
		}

		// load a slider by ID
		if ( isset( $_REQUEST['slider_id'] ) ) {
			$slider_id = intval( $_REQUEST['slider_id'] );
			// default to the latest slider
			$slide_id = $slide->find_slide( 'id', 'DESC', $slider_id ); 
		}

		// load a slide by ID
		if ( isset( $_REQUEST['slide_id'] ) ) {
			$slide_id = intval( $_REQUEST['slide_id'] );
		}

		// update slider settings
		if ( isset( $_POST['save'] ) && $slider_id ) {
			$data = '';
			$slider->update_slider( $slider_id, $data );
			$slide->update_slide( $slide_id, $data );
		}

		if ( $slider_id > 0 ) {
			$this->set_slider( $slider_id );

			if ( $slide_id > 0 ) {
				$this->set_slide( $slide_id );
			}
		}

	}

	/**
	 * Set the current slider
	 */
	public function set_slider( $slider_id ) {
		$this->slider = $slider_id;
	}
	/**
	 * Set the current slide
	 */
	public function set_slide( $slide_id ) {
		$this->slide = $slide_id;
	}




}
