<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Plugin_Name
 * @author    Your Name <email@example.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright 2014 Your Name or Company Name
 */
?>

<?php

$this->admin_process();
$max_tabs = 10;
$plugin_slug = 'luxeslider';
$slider = new LuxeSlider();
$slider->set_slider($this->slider);
$slider->set_slide($this->slide);
$settings = $slider->get_settings();
?>



<div class="wrap luxeslider">

	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

    <form accept-charset="UTF-8" action="?page=<?php echo $plugin_slug; ?>&amp;slider_id=<?php echo $this->slider ?>" method="post">

    	<input type="hidden" name="slider_id" value="<?php echo $this->slider; ?>">
    	<input type="hidden" name="slide_id" value="<?php echo $this->slide; ?>">
    	<?php 
        if ($this->slider) {
            wp_nonce_field($plugin_slug.'_save');
        }
        ?>

		<?php include_once( 'includes/slider-nav.php' ); ?>

        <div id='poststuff'>
            <div id='post-body' class='metabox-holder columns-2'>
        		<?php include_once( 'includes/slide-content.php' ); ?>
        		<?php include_once( 'includes/settings.php' ); ?>
            </div>
        </div>

    </form>

</div>
