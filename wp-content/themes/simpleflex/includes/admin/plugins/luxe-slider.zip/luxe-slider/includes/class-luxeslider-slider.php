<?php

	class LuxeSlider {
		
		private $id;
		private $slide_id;
		private $title;
		private $alias;
		private $arrParams;
		private $arrSlides = null;
		
		public function __construct(){
			$plugin = LuxeSliderPlugin::get_instance();
			$this->plugin_slug = $plugin->get_plugin_slug();			
		}
		
		/**
		 * 
		 * validate that the slider is inited. if not - throw error
		 */
		private function validateInited(){
			if(empty($this->id))
				UniteFunctionsRev::throwError("The slider is not inited!");
		}
		
		/**
		 * 
		 * init slider by db data
		 * 
		 */
		public function initByDBData($arrData){
			
			$this->id = $arrData["id"];
			$this->title = $arrData["title"];
			$this->alias = $arrData["alias"];
			
			$params = $arrData["params"];
			$params = (array)json_decode($params);
			
			$this->arrParams = $params;
		}
		
		
		/**
		 * 
		 * init the slider object by database id
		 */
		public function initByID($sliderID){
			UniteFunctionsRev::validateNumeric($sliderID,"Slider ID");
			$sliderID = $this->db->escape($sliderID);
			
			$sliderData = $this->db->fetchSingle(GlobalsRevSlider::$table_sliders,"id=$sliderID");
			
			$this->initByDBData($sliderData);
		}

		/**
		 * 
		 * init slider by alias
		 */
		public function initByAlias($alias){
			$alias = $this->db->escape($alias);
			$sliderData = $this->db->fetchSingle(GlobalsRevSlider::$table_sliders,"alias='$alias'");
			
			$this->initByDBData($sliderData);
		}
		
		
		/**
		 * 
		 * init by id or alias
		 */
		public function initByMixed($mixed){
			if(is_numeric($mixed))
				$this->initByID($mixed);
			else
				$this->initByAlias($mixed);
		}
		
		
		/**
		 * 
		 * get data functions
		 */
		public function getTitle(){
			return($this->title);
		}
		
		public function getID(){
			return($this->id);
		}
		
		public function getParams(){
			return($this->arrParams);
		}
		
		/**
		 * 
		 * get parameter from params array. if no default, then the param is a must!
		 */
		function getParam($name,$default=null){
			if($default == null){
				if(!array_key_exists($name, $this->arrParams))
					UniteFunctionsRev::throwError("The param <b>$name</b> not found in slider params.");
				$default = "";
			}
				
			return UniteFunctionsRev::getVal($this->arrParams, $name,$default);
		}
		
		public function getAlias(){
			return($this->alias);
		}
		
		/**
		 * get combination of title (alias)
		 */
		public function getShowTitle(){
			$showTitle = $this->title." ($this->alias)";
			return($showTitle);
		}
		
		/**
		 * 
		 * get slider shortcode
		 */
		public function getShortcode(){
			$shortCode = "[rev_slider {$this->alias}]";
			return($shortCode);
		}
		



		
    /**
     * Set the current slider
     */
    public function set_slider($slider_id) {
    	$this->id = $slider_id;
    }
		
    /**
     * Set the current slide
     */
    public function set_slide($slide_id) {
    	$this->slide_id = $slide_id;
    }

	/**
	 * Get slider settings
	 */
	public function get_settings(){
        global $wpdb;
        $table_suffix = '_sliders';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT * FROM $table WHERE id = $this->id" );
		$settings = unserialize($result->settings);
		return $settings;
	}

    /**
     * Create a new slider
     */
    public function add_slider() {
        // check nonce
        check_admin_referer($this->plugin_slug."_add_slider");
        // default options
        $options = array(
        	'slider_controls' => 'false',
        	'slider_pager' => 'true',
        	'slider_auto_change' => 'true',
        	'slider_responsive' => 'true',
        	'slider_dimensions_x' => '1170',
        	'slider_dimensions_y' => '400'
        	);  
        // store data in array
        $data = array();
		$data["title"] = 'New Slider';
		$data["alias"] = '';
		$data["settings"] = serialize($options); 

        global $wpdb;
        $table_suffix = '_sliders';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;	

		if(empty($slider_id)){	
			//create slider	
			$result = $wpdb->insert($table, $data);
			$slider_id = $wpdb->insert_id;
			return($slider_id);
		}
    }

    /**
     * Update slider (save)
     */
	public function update_slider($slider_id = null, $data){

		check_admin_referer($this->plugin_slug . '_save');
		// @TODO get post options and clean
        $data = array();
		$data["title"] = sanitize_text_field( $_POST['title'] );
		//$data["alias"] = sanitize_key( $_POST['alias'] );
		$data["settings"] = serialize($_POST['settings']); 

        global $wpdb;
        $table_suffix = '_sliders';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;	

		if(!empty($slider_id)){	
			//create slider	
			$result = $wpdb->update($table, $data, array('id'=>$slider_id));
			$slider_id = $wpdb->insert_id;
			return($slider_id);
		}

	}
    /**
     * Delete a slider and its slides
     *
     * @param int $id
     */
    public function delete_slider($slider_id = null) {
        // check nonce
        check_admin_referer($this->plugin_slug."_delete_slider");

        global $wpdb;
        $table_suffix = '_sliders';
        $slides_table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$slides_table = $wpdb->prefix.$this->plugin_slug.$slides_table_suffix;	

		$wpdb->query( 
			$wpdb->prepare( 
				"
		         DELETE FROM $table
				 WHERE id = %d
				",
			        $slider_id 
		        )
		);
		//delete all slides associated 
		$wpdb->query( 
			$wpdb->prepare( 
				"
		         DELETE FROM $slides_table
				 WHERE slider_id = %d
				",
			        $slider_id 
		        )
		);
		
    }



    /**
     * Get a slider id by column (latest by default)
     *
     * @param string $orderby field to order.
     * @param string $order direction (ASC or DESC).
     * @return int slider ID.
     */
    public function find_slider($orderby = 'id', $order = 'DESC') {

        global $wpdb;
        $table_suffix = '_sliders';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_row( "SELECT id FROM $table ORDER BY $orderby $order" );

        if ($result) {
            return $result->id;
        }

        return false;
    }


    /**
     * Get sliders. Returns a nicely formatted array of currently
     * published sliders.
     *
     * @param string $sort_key
     * @return array all published sliders
     */
    public function all_sliders($orderby = 'date') {

        $sliders = false;

        global $wpdb;
        $table_suffix = '_sliders';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_results( "SELECT * FROM ".$table );

        foreach ( $result as $slider ) {


            $active = $this->id && ($this->id == $slider->id) ? true : false;
            $sliders[] = array(
                'active' => $active,
                'title' => $slider->title,
                'id' => $slider->id
            );
        }

        return $sliders;
    }


    /**
     * Get slides. Returns a nicely formatted array of currently
     * published slides for navigation
     *
     * @param string $sort_key
     * @return array all published sliders
     */
    public function all_slides() {

        $slides = false;

        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$result = $wpdb->get_results( "SELECT * FROM ".$table ." WHERE slider_id=".$this->id." ORDER BY slide_order");

        foreach ( $result as $slide ) {

            $active = $this->slide_id && ($this->slide_id == $slide->id) ? true : false;
            $slides[] = array(
                'active' => $active,
                'title' => $slide->title,
                'id' => $slide->id
            );
        }

        return $slides;
    }

    /**
     * Get slides. Returns a nicely formatted array of currently
     * published slides for navigation
     *
     * @param string $sort_key
     * @return array all published sliders
     */
    public function get_all_slides() {
        $slides = false;

        global $wpdb;
        $table_suffix = '_slides';
		$table = $wpdb->prefix.$this->plugin_slug.$table_suffix;
		$slides = $wpdb->get_results( "SELECT * FROM ".$table ." WHERE slider_id=".$this->id." ORDER BY slide_order");
        return $slides;
    }




    /**
     * Create a new slide for this slider
     */
    public function add_slide() {

        // check nonce
        check_admin_referer($this->plugin_slug."_add_slide");
        // default options
        $options = array();  //serialized json @TODO

		//$data["settings"] = $options;
		//$data["layers"] = $layers; 
		if(isset($_REQUEST['slider_id'])) {

			$slider_id = intval($_REQUEST['slider_id']);

	        // store data in array
	        $data = array();
			$data["title"] = 'New Slide';
			$data["slider_id"] = $slider_id;
			$data["slide_order"] = '';

			$slide = new LuxeSlide();
			$slide_id = $slide->add_slide($data);
			return($slide_id);

		}

    }










		
		/**
		 * 
		 * shift order of the slides from specific order
		 */
		private function shiftOrder($fromOrder){
			
			$where = " slider_id={$this->id} and slide_order >= $fromOrder";
			$sql = "update ".GlobalsRevSlider::$table_slides." set slide_order=(slide_order+1) where $where";
			$this->db->runSql($sql);
			
		}
		
		

		
		
		/**
		 * 
		 * create a slide from input data
		 */
		public function createSlideFromData($data){
			
			$sliderID = UniteFunctionsRev::getVal($data, "sliderid");
			$urlImage = UniteFunctionsRev::getVal($data, "url_image");
			
			UniteFunctionsRev::validateNotEmpty($sliderID,"Slider ID");
			UniteFunctionsRev::validateNotEmpty($urlImage,"image url");
			$this->initByID($sliderID);
						
			$slide = new RevSlide();
			$slideID = $slide->createSlide($sliderID, $urlImage);
			return($slideID);
		}
		
		/**
		 * 
		 * update slides order from data
		 */
		public function updateSlidesOrderFromData($data){
			$sliderID = UniteFunctionsRev::getVal($data, "sliderID");
			$arrIDs = UniteFunctionsRev::getVal($data, "arrIDs");
			UniteFunctionsRev::validateNotEmpty($arrIDs,"slides");
			
			$this->initByID($sliderID);
			
			foreach($arrIDs as $index=>$slideID){
				$order = $index+1;
				$arrUpdate = array("slide_order"=>$order);
				$where = array("id"=>$slideID);
				$this->db->update(GlobalsRevSlider::$table_slides,$arrUpdate,$where);
			}
			
		}
		
		/**
		 * 
		 * get the "main" and "settings" arrays, for dealing with the settings.
		 */
		public function getSettingsFields(){
			$this->validateInited();
			
			$arrMain = array();
			$arrMain["title"] = $this->title;
			$arrMain["alias"] = $this->alias;
			
			$arrRespose = array("main"=>$arrMain,
								"params"=>$this->arrParams);
			
			return($arrRespose);
		}
		
		/**
		 * 
		 * get slides of the current slider
		 */
		public function getSlides(){
			$this->validateInited();
			$arrSlides = array();
			$arrSlideRecords = $this->db->fetch(GlobalsRevSlider::$table_slides,"slider_id=".$this->id,"slide_order");
			
			foreach ($arrSlideRecords as $record){
				$slide = new RevSlide();
				$slide->initByData($record);
				$arrSlides[] = $slide;
			}
			
			$this->arrSlides = $arrSlides;
			
			return($arrSlides);
		}
		

		
	}

?>