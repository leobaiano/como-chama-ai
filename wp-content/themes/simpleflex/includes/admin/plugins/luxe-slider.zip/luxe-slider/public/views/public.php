<?php
/**
 * Represents the view for the public-facing component of the plugin.
 *
 * This typically includes any information, if any, that is rendered to the
 * frontend of the theme when the plugin is activated.
 *
 * @package   Plugin_Name
 * @author    Your Name <email@example.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright 2014 Your Name or Company Name
 */
?>

		<div class="slider-wrapper luxeslider-wrapper">
			<div class="responsive-container" id="responsive-container-<?php echo $atts['id']; ?>">
				<div class="slider luxeslider" id="luxeslider-<?php echo $atts['id']; ?>">
					<div class="fs_loader"></div>
						<?php 
						$slides = $slider->get_all_slides();
						foreach ($slides as $slide) {  
						?>

						<div class="slide">

							<?php 
							$layers = unserialize($slide->layers); 
							if( $layers ) {
								//echo '<img class="alignnone size-full wp-image-555" alt="yellow-white phone-2" src="http://192.168.1.104/projects/SimpleFlex/wp-content/uploads/2014/03/yellow-white-phone-2.png" width="832" height="610">';
								foreach ($layers as $layer) { 

									// Fix for time "bug"
									$time = $layer["duration"] + $layer["delay"];

									// filter images out of content
									$dom = new DOMDocument();
									@$dom->loadHTML( $layer['content'] );
									$dom->preserveWhiteSpace = false;
									$images = $dom->getElementsByTagName('img');
									$image_layers = array();

									foreach ($images as $image) {

									    // get the widths of each image
									    //$width = $image->getAttribute('width');

									    // the existing classes already on the images
									    $existing_classes = $image->getAttribute('class');

									    // the class we're adding
									    $new_class = ' luxeslider-layer luxeslider-layer-image';

									    // the existing classes plus the new class
									    $class_names_to_add = $existing_classes . $new_class;
										$image->setAttribute('class', $class_names_to_add);

										// add layer settings to image and save in array
										$image->setAttribute('data-position', $layer["position_y"].','.$layer["position_x"]);
										$image->setAttribute('data-step', $layer["step"]);
										$image->setAttribute('data-in', $layer["animation_in"]);
										$image->setAttribute('data-out', $layer["animation_out"]);
										$image->setAttribute('data-ease-in', $layer["easing_in"]);
										$image->setAttribute('data-ease-out', $layer["easing_out"]);
										$image->setAttribute('data-delay', $layer["delay"]);
										$image->setAttribute('data-time', $time);
										$image_layers[] = $dom->saveHTML($image);

										// delete image from content layer
										$image->parentNode->removeChild($image);

									}
									$layer['content'] = $dom->saveHTML();

									// echo image layers
									foreach ($image_layers as $image_layer) {
										echo $image_layer;
									}

									// echo layer content
									echo '<div class="luxeslider-layer" '
										.'data-position="'.$layer["position_y"].','.$layer["position_x"].'" '
										.'data-step="'.$layer["step"].'" '
										.'data-in="'.$layer["animation_in"].'" '
										.'data-out="'.$layer["animation_out"].'" '
										.'data-ease-in="'.$layer["easing_in"].'" '
										.'data-ease-out="'.$layer["easing_out"].'" '
										.'data-delay="'.$layer["delay"].'" '
										.'data-time="'.$time.'" '
										.'>';
										echo do_shortcode($layer['content']);
									echo '</div>';
							
								} 
							}
							?>
						</div>


						<?php } ?>

				</div>
			</div>
		</div>

<?php $settings = $slider->get_settings(); ?>

<script type="text/javascript">
	var sliderBackgroundColor = [];
	var sliderBackgroundImage = [];
	<?php
	$i = 0;
	foreach ($slides as $slide) {  
		$slide_settings = unserialize($slide->settings);
		echo "sliderBackgroundColor[{$i}] = '{$slide_settings['background_color']}';\n";
		echo "sliderBackgroundImage[{$i}] = '{$slide_settings['background_image']}';\n";
		$i++;
	}
	?>
	var totalSlides = <?php echo $i; ?>;
	var $sliderWrapper = jQuery('#responsive-container-<?php echo $atts['id']; ?>');
	jQuery('#luxeslider-<?php echo $atts['id']; ?>').fractionSlider({
		'fullWidth': 			true,
		'controls': 			<?php echo $settings['slider_controls']; ?>, 
		'pager': 				<?php echo $settings['slider_pager']; ?>,
		'responsive': 			<?php echo $settings['slider_responsive']; ?>,
		'dimensions': 			"<?php echo $settings['slider_dimensions_x']; ?>,<?php echo $settings['slider_dimensions_y']; ?>",
	    'increase': 			false,
		'pauseOnHover': 		false, //<?php //echo $settings['slider_pause_on_hover']; ?>, // seems to cause a bug with layers
		'slideEndAnimation': 	true,
		'slideChangeCallback' :function(el, currentSlide, lastSlide, step ){
			/* paramters:
			el = the slider element
			currentSlide = the current slide (in case of nextSlideCallback etc. its the new slide)
			lastSlide = the last/previouse slide
			step = the current step
			*/
				//bg-color1 - class for #mainslider
			slideNumber = currentSlide;
			if(slideNumber > (totalSlides - 1)) {
				slideNumber = 0;
			}
			$sliderWrapper.css('background-color', sliderBackgroundColor[slideNumber]);
			if(sliderBackgroundImage[currentSlide]) {
				$sliderWrapper.css('background-image', 'url('+sliderBackgroundImage[slideNumber]+')');
			}
			else {
				$sliderWrapper.css('background-image', '');
			}
		}
	});


</script>