<?php
    if (!$this->slider) {
        return;
    }            
?>

<div id='postbox-container-1' class='postbox-container'>
    <div id="side-sortables" class="meta-box-sortables">
        <div class='right'>
        	<div class="postbox">
				<h3 class='configuration'>
					<?php _e("Slider Settings", $plugin_slug) ?>
                    <input class='alignright button button-primary' type='submit' name='save' id='luxe-save' value='<?php _e("Save", "metaslider") ?>' />
                    <span class="spinner"></span>
                </h3>
                <div class="inside">
					<h4>Shortcode</h4>
					<p><?php _e("Add this shortcode anywhere in your site to use your slider.", "metaslider"); ?></p>
					<input readonly='readonly' type='text' value='[luxeslider id=<?php echo $this->slider ?>]' /></div>
                    <table class="widefat settings">

                        <tbody>
	                        <tr>
	                            <th style="width: 100px;" colspan="2">
	                                <h4><?php _e("Slider Options", $plugin_slug) ?></h4>
	                            </th>
	                        </tr>
                        	<tr>
                        		<td><label for="slider_controls"><?php _e("Arrows", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="radio" name="settings[slider_controls]" value="true" <?php echo ($settings['slider_controls'] == 'true' ? 'checked="checked"' : ''); ?>><?php _e("Show", $plugin_slug) ?>
									<input type="radio" name="settings[slider_controls]" value="false" <?php echo ($settings['slider_controls'] == 'false' ? 'checked="checked"' : ''); ?>><?php _e("Hide", $plugin_slug) ?>
								</td>
							</tr>
                        	<tr>
                        		<td><label for="slider_pager"><?php _e("Pager", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="radio" name="settings[slider_pager]" value="true" <?php echo ($settings['slider_pager'] == 'true' ? 'checked="checked"' : ''); ?>><?php _e("Show", $plugin_slug) ?>
									<input type="radio" name="settings[slider_pager]" value="false" <?php echo ($settings['slider_pager'] == 'false' ? 'checked="checked"' : ''); ?>><?php _e("Hide", $plugin_slug) ?>
								</td>
							</tr>
                        	<tr>
                        		<td><label for="slider_auto_change"><?php _e("Auto Change", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="radio" name="settings[slider_auto_change]" value="true" <?php echo ($settings['slider_auto_change'] == 'true' ? 'checked="checked"' : ''); ?>><?php _e("True", $plugin_slug) ?>
									<input type="radio" name="settings[slider_auto_change]" value="false" <?php echo ($settings['slider_auto_change'] == 'false' ? 'checked="checked"' : ''); ?>><?php _e("False", $plugin_slug) ?>
								</td>
							</tr>
                        	<!--<tr>
                        		<td><label for="slider_pause_on_hover"><?php //_e("Pause on Hover", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="radio" name="settings[slider_pause_on_hover]" value="true" <?php echo ($settings['slider_pause_on_hover'] == 'true' ? 'checked="checked"' : ''); ?>><?php _e("True", $plugin_slug) ?>
									<input type="radio" name="settings[slider_pause_on_hover]" value="false" <?php echo ($settings['slider_pause_on_hover'] == 'false' ? 'checked="checked"' : ''); ?>><?php _e("False", $plugin_slug) ?>
								</td>
							</tr>-->
                        	<tr>
                        		<td><label for="slider_responsive"><?php _e("Responsive", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="radio" name="settings[slider_responsive]" value="true" <?php echo ($settings['slider_responsive'] == 'true' ? 'checked="checked"' : ''); ?>><?php _e("True", $plugin_slug) ?>
									<input type="radio" name="settings[slider_responsive]" value="false" <?php echo ($settings['slider_responsive'] == 'false' ? 'checked="checked"' : ''); ?>><?php _e("False", $plugin_slug) ?>
								</td>
							</tr>
	                        <tr>
	                            <th style="width: 100px;" colspan="2">
	                                <h4><?php _e("Slider Dimensions (in pixels)", $plugin_slug) ?></h4>
	                            </th>
	                        </tr>
                        	<tr>
                        		<td><label for="slider_dimensions_x"><?php _e("Slider Width", $plugin_slug) ?></label></td>
                        		<td>
	                        		<input type="text" name="settings[slider_dimensions_x]" class="small-int" value="<?php echo $settings['slider_dimensions_x']; ?>">
								</td>
							</tr>
                        	<tr>
                        		<td><label for="slider_dimensions_x"><?php _e("Slider Height", $plugin_slug) ?></label></td>
                        		<td>
									<input type="text" name="settings[slider_dimensions_y]" class="small-int" value="<?php echo $settings['slider_dimensions_y']; ?>">
								</td>
							</tr>
							<tr>
								<td>
									<a id="move-sidebar" class='move-sidebar button-secondary' href='#'><?php _e("Move Sidebar", $plugin_slug) ?></a>
								</td>
								<td>
								    <a id="delete-slider" class='delete-slider alignright button-secondary confirm' href='<?php echo wp_nonce_url("?page=".$plugin_slug."&amp;delete_slider={$this->slider}", $plugin_slug."_delete_slider"); ?>'><?php _e("Delete Slider", $plugin_slug) ?></a>
								</td>
							</tr>
                        </tbody>
                    </table>
				</div>
	

        </div>
    </div>
</div>