<?php
/**
 * The WordPress Plugin Boilerplate.
 *
 * A foundation off of which to build well-documented WordPress plugins that
 * also follow WordPress Coding Standards and PHP best practices.
 *
 * @package   Luxe Slider
 * @author    Joshua Flowers <joshua@themeluxe.com>
 * @license   GPL-2.0+
 * @link      http://themeluxe.com
 * @copyright 2014 ThemeLuxe
 *
 * @wordpress-plugin
 * Plugin Name:       Luxe Slider
 * Plugin URI:        http://themeluxe.com
 * Description:       Parallax layer slider
 * Version:           1.0.1
 * Author:            Joshua Flowers
 * Author URI:        http://themeluxe.com
 * Text Domain:       plugin-name-locale
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 * GitHub Plugin URI: https://github.com/themeluxe/luxe-slider
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/*----------------------------------------------------------------------------*
 * Public-Facing Functionality
 *----------------------------------------------------------------------------*/

require_once( plugin_dir_path( __FILE__ ) . 'class-luxeslider-plugin.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/class-luxeslider-slider.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/class-luxeslider-slide.php' );
//require_once( plugin_dir_path( __FILE__ ) . 'public/class-luxe-slider-public.php' );
//require_once( plugin_dir_path( __FILE__ ) . 'public/class-luxe-slide-public.php' );

/*
 * Register hooks that are fired when the plugin is activated or deactivated.
 * When the plugin is deleted, the uninstall.php file is loaded.
 */
register_activation_hook( __FILE__, array( 'LuxeSliderPlugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'LuxeSliderPlugin', 'deactivate' ) );


add_action( 'plugins_loaded', array( 'LuxeSliderPlugin', 'get_instance' ) );

/*----------------------------------------------------------------------------*
 * Dashboard and Administrative Functionality
 *----------------------------------------------------------------------------*/

/*
 * @TODO:
 *
 * - replace `class-plugin-name-admin.php` with the name of the plugin's admin file
 * - replace Plugin_Name_Admin with the name of the class defined in
 *   `class-plugin-name-admin.php`
 *
 * If you want to include Ajax within the dashboard, change the following
 * conditional to:
 *
 * if ( is_admin() ) {
 *   ...
 * }
 *
 * The code below is intended to to give the lightest footprint possible.
 */
if ( is_admin() && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) ) {

	require_once( plugin_dir_path( __FILE__ ) . 'admin/class-luxeslider-admin.php' );
	add_action( 'plugins_loaded', array( 'LuxeSliderAdmin', 'get_instance' ) );

}